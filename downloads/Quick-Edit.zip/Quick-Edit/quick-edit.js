jQuery(document).ready(function ($) {
 $('#quick-edit-form').on('submit', function (e) {
   e.preventDefault();
   const formData = $(this).serialize();

   $.ajax({
     url: quickEdit.ajax_url,
     method: 'POST',
     data: {
       action: 'quick_add_save_edits_bulk',
       security: quickEdit.nonce,
       data: formData
     },
     success: function (response) {
       if (response.success) {
         alert(response.data);
         window.location.href = '/wp-admin/edit.php?post_type=product';
       } else {
         alert('Error: ' + response.data);
       }
     },
     error: function () {
       alert('Server error occurred.');
     }
   });
 });
});

