<style>
#quick-edit-form {
  margin-top: 20px;
  overflow-x: auto;
  white-space: nowrap;
}
#quick-edit-form table.wp-list-table {
  width: max-content;
  border-collapse: collapse;
  min-width: 1400px;
}
#quick-edit-form table.wp-list-table th,
#quick-edit-form table.wp-list-table td {
  padding: 10px;
  border-bottom: 1px solid #ddd;
  vertical-align: middle;
}
#quick-edit-form input[type="text"],
#quick-edit-form input[type="number"],
#quick-edit-form input[type="url"],
#quick-edit-form input[type="date"] {
  width: 180px;
  padding: 6px 8px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
#quick-edit-form button {
  margin-top: 20px;
}
</style>
<div class="wrap">
  <h1>Quick Edit Products</h1>
  <form id="quick-edit-form">
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>SKU</th>
          <th>GTIN/UPC/EAN/ISBN</th>
          <th>Regular Price</th>
          <th>Sale Price</th>
          <th>Sale Start</th>
          <th>Sale End</th>
          <th>Short Description</th>
          <th>Product Description</th>
          <th>Categories</th>
          <th>Tags</th>
          <th>Manage Stock?</th>
          <th>Stock Qty</th>
          <th>Stock Status</th>
          <th>Tax Status</th>
          <th>Tax Class</th>
          <th>Weight</th>
          <th>Length</th>
          <th>Width</th>
          <th>Height</th>
          <th>Shipping Class</th>
          <th>External URL</th>
          <th>Button Text</th>
          <th>Slug</th>
          <th>Catalog Visibility</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $product):
          $meta = fn($key) => get_post_meta($product->ID, $key, true);
        ?>
        <tr>
          <td><input type="text" name="products[<?= $product->ID ?>][product_name]" value="<?= esc_attr($product->post_title) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][sku]" value="<?= esc_attr($meta('_sku')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][gtin]" value="<?= esc_attr($meta('_wc_gpf_google_product_category')) ?>"></td>
          <td><input type="number" step="0.01" name="products[<?= $product->ID ?>][regular_price]" value="<?= esc_attr($meta('_regular_price')) ?>"></td>
          <td><input type="number" step="0.01" name="products[<?= $product->ID ?>][sale_price]" value="<?= esc_attr($meta('_sale_price')) ?>"></td>
          <td><input type="date" name="products[<?= $product->ID ?>][sale_start]" value="<?= esc_attr($meta('_sale_price_dates_from')) ?>"></td>
          <td><input type="date" name="products[<?= $product->ID ?>][sale_end]" value="<?= esc_attr($meta('_sale_price_dates_to')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][short_description]" value="<?= esc_attr($product->post_excerpt) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][long_description]" value="<?= esc_attr($product->post_content) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][categories]" value="<?= esc_attr(implode(',', wp_get_post_terms($product->ID, 'product_cat', ['fields' => 'names']))) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][tags]" value="<?= esc_attr(implode(',', wp_get_post_terms($product->ID, 'product_tag', ['fields' => 'names']))) ?>"></td>
          <td><input type="checkbox" name="products[<?= $product->ID ?>][manage_stock]" <?= checked('yes', $meta('_manage_stock'), false) ?>></td>
          <td><input type="number" name="products[<?= $product->ID ?>][stock_qty]" value="<?= esc_attr($meta('_stock')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][stock_status]" value="<?= esc_attr($meta('_stock_status')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][tax_status]" value="<?= esc_attr($meta('_tax_status')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][tax_class]" value="<?= esc_attr($meta('_tax_class')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][weight]" value="<?= esc_attr($meta('_weight')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][length]" value="<?= esc_attr($meta('_length')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][width]" value="<?= esc_attr($meta('_width')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][height]" value="<?= esc_attr($meta('_height')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][shipping_class]" value="<?= esc_attr($meta('_shipping_class')) ?>"></td>
          <td><input type="url" name="products[<?= $product->ID ?>][external_url]" value="<?= esc_attr($meta('_product_url')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][button_text]" value="<?= esc_attr($meta('_button_text')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][slug]" value="<?= esc_attr($product->post_name) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][visibility]" value="<?= esc_attr($meta('_visibility')) ?>"></td>
          <td>
            <select name="products[<?= $product->ID ?>][status]">
              <option value="publish" <?= selected($product->post_status, 'publish', false) ?>>Publish</option>
              <option value="draft" <?= selected($product->post_status, 'draft', false) ?>>Draft</option>
              <option value="pending" <?= selected($product->post_status, 'pending', false) ?>>Pending</option>
            </select>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <button type="submit" class="button button-primary">Save All Edits</button>
  </form>
</div>
