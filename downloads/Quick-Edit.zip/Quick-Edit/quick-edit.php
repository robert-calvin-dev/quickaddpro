<?php
/**
 * Plugin Name: Quick Edit
 * Plugin URI: https://yourrealwebsite.com/quick-add
 * Description: A powerful WooCommerce tool for rapid product editing with streamlined fields.
 * Version: 1.0.0
 * Author: Robert Calvin
 * Author URI: https://yourrealwebsite.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-edit
 */

add_action('admin_menu', function () {
  add_menu_page('Quick Edit', 'Quick Edit', 'manage_options', 'quick-edit', 'render_quick_edit_page', 'dashicons-edit', 58);
});

add_action('admin_enqueue_scripts', function ($hook) {
  if ($hook === 'toplevel_page_quick-edit') {
    wp_enqueue_script('quick-edit-js', plugin_dir_url(__FILE__) . 'quick-edit.js', ['jquery'], null, true);
    wp_localize_script('quick-edit-js', 'quickEdit', [
      'ajax_url' => admin_url('admin-ajax.php'),
      'nonce'    => wp_create_nonce('quick_edit_nonce')
    ]);
  }
});

function render_quick_edit_page() {
  if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
  }

  $products = get_posts([
    'post_type'      => 'product',
    'posts_per_page' => -1,
    'post_status'    => 'publish',
  ]);

  include plugin_dir_path(__FILE__) . 'quick-edit-template.php';
}

function quick_add_save_edits_bulk_handler() {
  check_ajax_referer('quick_edit_nonce', 'security');
  parse_str($_POST['data'], $form_data);

  if (empty($form_data['products'])) {
    wp_send_json_error('No product data received.');
  }

  foreach ($form_data['products'] as $product_id => $product_data) {
    quick_add_save_edits(intval($product_id), $product_data);
  }

  wp_send_json_success('All products updated successfully.');
}

function quick_add_save_edits($product_id, $data) {
  if (!current_user_can('edit_post', $product_id)) return;

  wp_update_post([
    'ID'           => $product_id,
    'post_title'   => sanitize_text_field($data['product_name']),
    'post_excerpt' => sanitize_textarea_field($data['short_description']),
    'post_content' => wp_kses_post($data['long_description']),
    'post_name'    => sanitize_title($data['slug']),
    'post_status'  => in_array($data['status'], ['publish', 'draft', 'pending']) ? $data['status'] : 'publish'
  ]);

  update_post_meta($product_id, '_sku', wc_clean($data['sku']));
  update_post_meta($product_id, '_wc_gpf_google_product_category', sanitize_text_field($data['gtin']));
  update_post_meta($product_id, '_regular_price', wc_format_decimal($data['regular_price']));
  update_post_meta($product_id, '_sale_price', wc_format_decimal($data['sale_price']));
  update_post_meta($product_id, '_price', $data['sale_price'] !== '' ? wc_format_decimal($data['sale_price']) : wc_format_decimal($data['regular_price']));
  update_post_meta($product_id, '_sale_price_dates_from', $data['sale_start']);
  update_post_meta($product_id, '_sale_price_dates_to', $data['sale_end']);

  update_post_meta($product_id, '_manage_stock', isset($data['manage_stock']) ? 'yes' : 'no');
  update_post_meta($product_id, '_stock', intval($data['stock_qty']));
  update_post_meta($product_id, '_stock_status', sanitize_text_field($data['stock_status']));

  update_post_meta($product_id, '_tax_status', sanitize_text_field($data['tax_status']));
  update_post_meta($product_id, '_tax_class', sanitize_text_field($data['tax_class']));

  update_post_meta($product_id, '_weight', sanitize_text_field($data['weight']));
  update_post_meta($product_id, '_length', sanitize_text_field($data['length']));
  update_post_meta($product_id, '_width', sanitize_text_field($data['width']));
  update_post_meta($product_id, '_height', sanitize_text_field($data['height']));
  update_post_meta($product_id, '_shipping_class', sanitize_text_field($data['shipping_class']));

  update_post_meta($product_id, '_product_url', esc_url_raw($data['external_url']));
  update_post_meta($product_id, '_button_text', sanitize_text_field($data['button_text']));

  update_post_meta($product_id, '_visibility', sanitize_text_field($data['visibility']));

  if (!empty($data['categories'])) {
    $cats = array_map('trim', explode(',', $data['categories']));
    wp_set_object_terms($product_id, $cats, 'product_cat');
  }
  if (!empty($data['tags'])) {
    $tags = array_map('trim', explode(',', $data['tags']));
    wp_set_object_terms($product_id, $tags, 'product_tag');
  }

  wc_delete_product_transients($product_id);
}

add_action('wp_ajax_quick_add_save_edits_bulk', 'quick_add_save_edits_bulk_handler');
