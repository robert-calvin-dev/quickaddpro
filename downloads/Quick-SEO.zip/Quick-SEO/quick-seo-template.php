<style>
#quick-seo-form {
  margin-top: 20px;
  overflow-x: auto;
  white-space: nowrap;
}
#quick-seo-form table.wp-list-table {
  width: max-content;
  border-collapse: collapse;
  min-width: 1400px;
}
#quick-seo-form table.wp-list-table th,
#quick-seo-form table.wp-list-table td {
  padding: 10px;
  border-bottom: 1px solid #ddd;
  vertical-align: middle;
}
#quick-seo-form input[type="text"],
#quick-seo-form input[type="url"],
#quick-seo-form textarea {
  width: 200px;
  padding: 6px 8px;
  font-size: 13px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
</style>
<div class="wrap">
  <h1>Quick SEO Free - Spreadsheet View</h1>
  <form id="quick-seo-form">
    <table class="wp-list-table widefat fixed striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>Focus Keyword</th>
          <th>SEO Title</th>
          <th>Meta Description</th>
          <th>Social Media Title</th>
          <th>Social Media Description</th>
          <th>Social Media Image</th>
          <th>Inject Product Schema?</th>
          <th>Schema Output</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $product):
          $meta = fn($key) => get_post_meta($product->ID, $key, true);
        ?>
        <tr>
          <td><?= esc_html($product->post_title) ?></td>
          <td><input type="text" name="products[<?= $product->ID ?>][keyword]" value="<?= esc_attr($meta('seo_keywords')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][seo_title]" value="<?= esc_attr($meta('seo_title')) ?>"></td>
          <td><textarea name="products[<?= $product->ID ?>][meta_description]"><?= esc_textarea($meta('seo_description')) ?></textarea></td>
          <td><input type="text" name="products[<?= $product->ID ?>][social_title]" value="<?= esc_attr($meta('seo_og_title')) ?>"></td>
          <td><input type="text" name="products[<?= $product->ID ?>][social_desc]" value="<?= esc_attr($meta('seo_og_description')) ?>"></td>
          <td>
            <input type="text" name="products[<?= $product->ID ?>][social_image]" id="image_field_<?= $product->ID ?>" value="<?= esc_attr($meta('seo_og_image')) ?>">
          </td>
          <td><input type="checkbox" class="inject-schema-toggle" name="products[<?= $product->ID ?>][include_schema]" <?= $meta('include_schema') === '1' ? 'checked' : '' ?>></td>
          <td><textarea class="schema-output" name="products[<?= $product->ID ?>][schema_data]" style="width: 300px; height: 100px; background: #f7f7f7; font-size: 11px; font-family: monospace;"><?= esc_textarea($meta('schema_data')) ?></textarea></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <p><button type="submit" class="button button-primary">Save SEO Fields</button></p>
  </form>
</div>
<script>
jQuery(document).ready(function ($) {
  $('.upload-image').on('click', function (e) {
    e.preventDefault();
    const field = $(this).data('target');
    const media = wp.media({ title: 'Select Image', multiple: false });
    media.on('select', function () {
      const selected = media.state().get('selection').first().toJSON();
      $(field).val(selected.url);
    });
    media.open();
  });

  $('.inject-schema-toggle').on('change', function () {
    const $row = $(this).closest('tr');
    const name = $row.find('td:first').text().trim();
    const output = $row.find('.schema-output');
    if ($(this).is(':checked')) {
      const schema = {
        '@context': 'https://schema.org/',
        '@type': 'Product',
        'name': name
      };
      output.val(JSON.stringify(schema, null, 2));
    } else {
      output.val('');
    }
  });
});
</script>