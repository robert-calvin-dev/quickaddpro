<?php
/**
 * Plugin Name: Quick SEO
 * Description: Spreadsheet-style SEO editor for WooCommerce products.
 * Version: 1.0.0
 * Author: Robert Calvin
 * Text Domain: quick-seo
 */

add_action('admin_menu', function () {
  add_menu_page('Quick SEO', 'Quick SEO', 'manage_options', 'quick-seo', 'render_quick_seo_page', 'dashicons-chart-line', 58);
});

add_action('admin_enqueue_scripts', function ($hook) {
  if ($hook === 'toplevel_page_quick-seo') {
    wp_enqueue_script('quick-seo-js', plugin_dir_url(__FILE__) . 'quick-seo.js', ['jquery'], null, true);
    wp_localize_script('quick-seo-js', 'quickSEO', [
      'ajax_url' => admin_url('admin-ajax.php'),
      'nonce'    => wp_create_nonce('quick_seo_nonce')
    ]);
  }
});

function render_quick_seo_page() {
  if (!current_user_can('manage_options')) {
    wp_die(__('You do not have permission to access this page.'));
  }
  $products = get_posts([
    'post_type'      => 'product',
    'posts_per_page' => -1,
    'post_status'    => 'publish',
  ]);
  include plugin_dir_path(__FILE__) . 'quick-seo-template.php';
}

add_action('wp_ajax_quick_seo_save_edits_bulk', function () {
  check_ajax_referer('quick_seo_nonce', 'security');
  parse_str($_POST['data'], $form);
  if (empty($form['products'])) {
    wp_send_json_error('No data received.');
  }
  foreach ($form['products'] as $post_id => $data) {
    update_post_meta($post_id, 'seo_keywords', sanitize_text_field($data['keyword']));
    update_post_meta($post_id, 'seo_title', sanitize_text_field($data['seo_title']));
    update_post_meta($post_id, 'seo_description', sanitize_textarea_field($data['meta_description']));
    update_post_meta($post_id, 'seo_og_title', sanitize_text_field($data['social_title']));
    update_post_meta($post_id, 'seo_og_description', sanitize_textarea_field($data['social_desc']));
    update_post_meta($post_id, 'seo_og_image', esc_url_raw($data['social_image']));
    update_post_meta($post_id, 'include_schema', isset($data['include_schema']) ? '1' : '');
    update_post_meta($post_id, 'schema_data', sanitize_textarea_field($data['schema_data']));

  }
  wp_send_json_success('SEO data updated successfully.');
});

add_filter('manage_product_posts_columns', function ($columns) {
  $columns['seo_keywords'] = 'Focus Keyword';
  $columns['seo_title'] = 'SEO Title';
  return $columns;
});

add_action('manage_product_posts_custom_column', function ($column, $post_id) {
  if ($column === 'seo_keywords') echo esc_html(get_post_meta($post_id, 'seo_keywords', true));
  if ($column === 'seo_title') echo esc_html(get_post_meta($post_id, 'seo_title', true));
}, 10, 2);

add_action('add_meta_boxes', function () {
  add_meta_box('quick_seo_box', 'Quick SEO', 'render_quick_seo_meta_box', 'product', 'normal', 'default');
});

function render_quick_seo_meta_box($post) {
  $meta = fn($key) => get_post_meta($post->ID, $key, true);
  $checked = $meta('include_schema') === '1' ? 'checked' : '';
  echo '<p><label>Focus Keyword<br><input name="seo_keywords" value="' . esc_attr($meta('seo_keywords')) . '" style="width:100%"></label></p>';
  echo '<p><label>SEO Title<br><input name="seo_title" value="' . esc_attr($meta('seo_title')) . '" style="width:100%"></label></p>';
  echo '<p><label>Meta Description<br><textarea name="seo_description" style="width:100%">' . esc_textarea($meta('seo_description')) . '</textarea></label></p>';
  echo '<p><label>Social Media Title<br><input name="seo_og_title" value="' . esc_attr($meta('seo_og_title')) . '" style="width:100%"></label></p>';
  echo '<p><label>Social Media Description<br><input name="seo_og_description" value="' . esc_attr($meta('seo_og_description')) . '" style="width:100%"></label></p>';
  echo '<p><label>Social Media Image URL<br>
  <input id="seo_og_image" name="seo_og_image" value="' . esc_url($meta('seo_og_image')) . '" style="width:80%">
  </label></p>';
  echo '<p><label><input type="checkbox" name="include_schema" value="1" ' . $checked . '> Inject Product Schema JSON</label></p>';
  echo '<p><label>Schema JSON<br><textarea name="schema_data" style="width:100%;height:100px">' . esc_textarea($meta('schema_data')) . '</textarea></label></p>';
}

add_action('save_post_product', function ($post_id) {
  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
  if (!current_user_can('edit_post', $post_id)) return;

  $fields = [
    'seo_keywords', 'seo_title', 'seo_description', 'seo_og_title', 'seo_og_description', 'seo_og_image', 'schema_data'
  ];
  foreach ($fields as $field) {
    if (isset($_POST[$field])) {
      update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
    }
  }
  if (isset($_POST['include_schema'])) {
   update_post_meta($post_id, 'include_schema', '1');
 
   if (empty($_POST['schema_data'])) {
     $product = wc_get_product($post_id);
     $schema_json = json_encode([
       '@context' => 'https://schema.org/',
       '@type' => 'Product',
       'name' => $product->get_name(),
       'sku' => $product->get_sku(),
       'description' => $product->get_description(),
       'offers' => [
         '@type' => 'Offer',
         'price' => $product->get_price(),
         'priceCurrency' => get_woocommerce_currency()
       ]
     ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
     
     update_post_meta($post_id, 'schema_data', $schema_json);
   }
 } else {
   update_post_meta($post_id, 'include_schema', '');
 }
  update_post_meta($post_id, 'include_schema', isset($_POST['include_schema']) ? '1' : '');
});

add_action('wp_head', function () {
  if (!is_product()) return;
  global $post;
  $seo_title       = get_post_meta($post->ID, 'seo_title', true);
  $seo_description = get_post_meta($post->ID, 'seo_description', true);
  $og_title        = get_post_meta($post->ID, 'seo_og_title', true);
  $og_description  = get_post_meta($post->ID, 'seo_og_description', true);
  $og_image        = get_post_meta($post->ID, 'seo_og_image', true);
  $schema          = get_post_meta($post->ID, 'schema_data', true);
  $include_schema  = get_post_meta($post->ID, 'include_schema', true);

  if ($seo_title) {
    echo "<title>" . esc_html($seo_title) . "</title>\n";
    echo '<meta name="title" content="' . esc_attr($seo_title) . '">' . PHP_EOL;
  }
  if ($seo_description) {
    echo '<meta name="description" content="' . esc_attr($seo_description) . '">' . PHP_EOL;
  }
  if ($og_title) {
    echo '<meta property="og:title" content="' . esc_attr($og_title) . '">' . PHP_EOL;
  }
  if ($og_description) {
    echo '<meta property="og:description" content="' . esc_attr($og_description) . '">' . PHP_EOL;
  }
  if ($og_image) {
    echo '<meta property="og:image" content="' . esc_url($og_image) . '">' . PHP_EOL;
  }
  if ($include_schema && $schema) {
    echo '<script type="application/ld+json">' . $schema . '</script>' . PHP_EOL;
  }
});