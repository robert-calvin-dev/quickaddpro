
jQuery(document).ready(function ($) {
  $('#quick-seo-form').on('submit', function (e) {
    e.preventDefault();
    const formData = $(this).serialize();

    $.ajax({
      url: quickSEO.ajax_url,
      method: 'POST',
      data: {
        action: 'quick_seo_save_edits_bulk',
        security: quickSEO.nonce,
        data: formData
      },
      success: function (response) {
        if (response.success) {
          alert(response.data);
          window.location.href = '/wp-admin/edit.php?post_type=product';
        } else {
          alert('Error: ' + response.data);
        }
      },
      error: function () {
        alert('Server error occurred.');
      }
    });
  });

  $('.inject-schema-toggle').on('change', function () {
    const $row = $(this).closest('tr');
    const name = $row.find('td:first').text().trim();
    const output = $row.find('.schema-output');
    if ($(this).is(':checked')) {
      const schema = {
        '@context': 'https://schema.org/',
        '@type': 'Product',
        'name': name
      };
      output.val(JSON.stringify(schema, null, 2));
    } else {
      output.val('');
    }
  });
});
