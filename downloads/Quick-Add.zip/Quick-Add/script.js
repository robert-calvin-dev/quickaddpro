jQuery(document).ready(function ($) {
  const productTemplate = $('#product-template').html();

  const addProduct = () => {
    const $template = $(productTemplate);
    const index = $('.product-block').length;
    $template.find('[name^="download_url"]').each(function () {
      this.name = this.name.replace('0', index);
    });
    $template.find('[name^="download_name"]').each(function () {
      this.name = this.name.replace('0', index);
    });
    $('#product-container').append($template);
  };

  $('#add-product').on('click', function (e) {
    e.preventDefault();
    addProduct();
  });

  $(document).on('click', '.upload_image_button', function (e) {
    e.preventDefault();
    const button = $(this);
    const uploader = wp.media({ title: 'Select Image', button: { text: 'Use this image' }, multiple: false });
    uploader.on('select', function () {
      const attachment = uploader.state().get('selection').first().toJSON();
      button.after(`<input type="hidden" name="product_image[]" value="${attachment.url}"><img src="${attachment.url}" style="max-width:100px; display:block; margin-top:5px;">`);
    });
    uploader.open();
  });

  $(document).on('change', '.schedule-sale-checkbox', function () {
    const container = $(this).closest('.product-block');
    container.find('.sale-fields').toggle(this.checked);
  });

  $(document).on('change', '.downloadable-toggle', function () {
    const container = $(this).closest('.product-block');
    container.find('.download-fields').toggle(this.checked);
  });

  $(document).on('change', 'input[name="virtual[]"]', function () {
    const container = $(this).closest('.product-block');
    container.find('.shipping-fields').toggle(!this.checked);
  });

  $(document).on('click', '.add-download-file', function (e) {
    e.preventDefault();
    const block = $(this).siblings('.download-file-block:last');
    const clone = block.clone();
    clone.find('input').val('');
    block.parent().append(clone);
  });

  $(document).on('change', 'select[name="product_type[]"]', function () {
    const $block = $(this).closest('.product-block');
    const type = $(this).val();
    $block.find('.external-url-wrapper').toggle(type === 'external');
  });

  $('#product-form').on('submit', function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append('action', 'ipf_save_product');
    formData.append('nonce', ipf_ajax.nonce);

    $.ajax({
      url: ipf_ajax.ajax_url,
      method: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      dataType: 'json',
      success: function (response) {
        if (response.success) {
          alert('Products submitted successfully.');
          window.location.href = '/wp-admin/edit.php?post_type=product';
        } else {
          alert('Error submitting products.');
        }
      },
      error: function () {
        alert('Server error submitting products.');
      }
    });
  });
});
