<?php
/**
 * Plugin Name: Quick Add
 * Plugin URI: https://yourdomain.com/quick-add
 * Description: Quick Add is a powerful WooCommerce companion that allows you to create products quickly from a custom admin screen, with SKU and ID automation. Pro version includes SEO, social, and schema fields.
 * Version: 1.0
 * Author: Robert Calvin
 * Author URI: https://yourdomain.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-add
 */

add_action('admin_menu', function () {
    add_menu_page('Quick Add Products', 'Quick Add', 'manage_woocommerce', 'quick-add', 'quick_add_page', 'dashicons-products', 58);
});

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook === 'toplevel_page_quick-add') {
        wp_enqueue_media();
        wp_enqueue_script('quick-add-js', plugin_dir_url(__FILE__) . 'script.js', ['jquery'], null, true);
        wp_localize_script('quick-add-js', 'ipf_ajax', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('ipf_nonce'),
    
        
            'grouped_products' => get_posts(['post_type' => 'product', 'numberposts' => -1, 'post_status' => 'publish'])
        ]);
    }
});

function quick_add_page() {
    echo '<div class="wrap"><h1>Quick Add Products</h1>
    <form id="product-form">
        <button id="add-product" class="button">Add Product</button>
        <div id="product-container"></div>
        <p><input type="submit" class="button-primary" value="Submit Products"></p>
    </form></div>';
    echo '<script type="text/html" id="product-template">';
    include 'template-product-form.php';
    echo '</script>';
}

add_action('wp_ajax_ipf_save_product', function () {
    check_ajax_referer('ipf_nonce', 'nonce');

    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $count = count($_POST['product_name'] ?? []);
    for ($i = 0; $i < $count; $i++) {
        $post_id = wp_insert_post([
            'post_type' => 'product',
            'post_status' => 'publish',
            'post_title' => sanitize_text_field($_POST['product_name'][$i]),
            'post_content' => wp_kses_post($_POST['product_description'][$i]),
            'post_excerpt' => sanitize_text_field($_POST['short_description'][$i]),
            'post_name' => sanitize_title($_POST['slug'][$i]),
            'menu_order' => intval($_POST['menu_order'][$i])
        ]);

        if (is_wp_error($post_id)) continue;

        wp_set_object_terms($post_id, $_POST['categories'][$i] ?? [], 'product_cat');
        wp_set_object_terms($post_id, $_POST['tags'][$i] ?? [], 'product_tag');

        $meta_map = [
            'sku' => 'sku',
            'gtin' => '_wc_gpf_google_product_category',
            'regular_price' => '_regular_price',
            'sale_price' => '_sale_price',
            'sale_start' => '_sale_price_dates_from',
            'sale_end' => '_sale_price_dates_to',
            'tax_status' => '_tax_status',
            'tax_class' => '_tax_class',
            'weight' => '_weight',
            'length' => '_length',
            'width' => '_width',
            'height' => '_height',
            'shipping_class' => '_shipping_class',
            'stock_status' => '_stock_status',
            'stock_quantity' => '_stock',
            'manage_stock' => '_manage_stock',
            'backorders' => '_backorders',
            'sold_individually' => '_sold_individually',
            'external_url' => '_product_url',
            'button_text' => '_button_text',
            'purchase_note' => '_purchase_note',
            'reviews_allowed' => '_reviews_allowed',
            'catalog_visibility' => '_visibility',
            'featured' => '_featured'
        ];

        foreach ($meta_map as $key => $meta_key) {
            update_post_meta($post_id, $meta_key, $_POST[$key][$i] ?? '');
        }

        if (!empty($_POST['product_image'][$i]) && filter_var($_POST['product_image'][$i], FILTER_VALIDATE_URL)) {
            $tmp = download_url($_POST['product_image'][$i]);
            if (!is_wp_error($tmp)) {
                $file = [
                    'name'     => basename($_POST['product_image'][$i]),
                    'tmp_name' => $tmp
                ];
                $id = media_handle_sideload($file, $post_id);
                if (!is_wp_error($id)) {
                    set_post_thumbnail($post_id, $id);
                }
            }
        }

        $final_price = $_POST['sale_price'][$i] !== '' ? $_POST['sale_price'][$i] : $_POST['regular_price'][$i];
        update_post_meta($post_id, '_price', $final_price);

        $product = wc_get_product($post_id);

        switch ($_POST['product_type'][$i]) {
            case 'external': $product = new WC_Product_External($post_id); break;
            case 'variable': $product = new WC_Product_Variable($post_id); break;
            case 'grouped':  $product = new WC_Product_Grouped($post_id); break;
            default:         $product = new WC_Product_Simple($post_id); break;
        }

        $product->set_virtual(!empty($_POST['virtual'][$i]));
        $product->set_downloadable(!empty($_POST['downloadable'][$i]));
        $product->set_sku(sanitize_text_field($_POST['sku'][$i]));
        $product->set_manage_stock(!empty($_POST['manage_stock'][$i]));
        $product->set_stock_quantity(intval($_POST['stock_quantity'][$i]));
        $product->set_stock_status($_POST['stock_status'][$i] ?? 'instock');
        $product->set_tax_class($_POST['tax_class'][$i] ?? '');
        $product->set_tax_status($_POST['tax_status'][$i] ?? 'taxable');

        if (!empty($_POST['download_url'][$i])) {
            $downloads = [];
            foreach ($_POST['download_url'][$i] as $j => $url) {
                if (!filter_var($url, FILTER_VALIDATE_URL) || strpos($url, 'http') !== 0) continue;
                $d = new WC_Product_Download();
                $d->set_name(sanitize_text_field($_POST['download_name'][$i][$j] ?? 'Download'));
                $d->set_file(esc_url_raw($url));
                $downloads[] = $d;
            }
            $product->set_downloads($downloads);
        }

        $product->save();
    }

    wp_send_json_success();
});
