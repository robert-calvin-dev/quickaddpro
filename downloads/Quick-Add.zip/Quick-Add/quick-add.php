<?php
/**
 * Plugin Name: Quick Add
 * Plugin URI: https://yourdomain.com/quick-add
 * Description: Quick Add is a powerful WooCommerce companion that allows you to create products quickly from a custom admin screen, with SKU and ID automation. Pro version includes SEO, social, and schema fields.
 * Version: 1.0
 * Author: Robert Calvin
 * Author URI: https://yourdomain.com
 * License: GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quick-add
 */

if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_menu_page('Quick Add', 'Quick Add', 'manage_options', 'quick-add', 'render_interactive_product_form_page', 'dashicons-plus-alt', 56);
});

function render_interactive_product_form_page() {
    echo do_shortcode('[interactive_product_form]');
}

add_action('init', function () {
    add_shortcode('interactive_product_form', 'render_interactive_product_form');
});

function render_interactive_product_form() {
    ob_start();
    ?>
   <style>
 #product-form-wrapper {
            max-width: 100%;
            overflow-x: auto;
            padding: 20px;
        }
        #product-container {
            display: flex;
            flex-wrap: nowrap;
            gap: 20px;
        }
        .product-block {
            flex: 0 0 400px;
            background: #f6f6f6;
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        .standard-fields, .pro-fields {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .inline-group {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: center;
        }
        .inline-group label {
            flex: 1 1 22%;
            display: flex;
            align-items: center;
            justify-content: flex-start;
        }
        label {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 10px;
            width: 100%;
        }
        input[type="text"], input[type="number"], select, textarea {
            flex: 1;
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        textarea[name="long_description"] {
            height: 200px;
        }
        textarea {
            resize: vertical;
        }
        .pro-fields {
            background: #240046;
            color: #fff;
            padding: 16px;
            border-radius: 8px;
        }
        .pro-fields input,
        .pro-fields textarea {
            background: #eee;
            color: #333;
        }
        .pro-fields h3 {
            color: gold;
            text-align: center;
        }
        .form-actions {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }
        .grouped-products-wrapper {
            width: 50%;
        }

        select {
            width: 100%;
        }
        .form-actions button,
        #add-product {
            background: #a5e4e1;
            padding: 8px 16px;
            font-weight: bold;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
    </style>
    <div id="product-form-wrapper">
        <button id="add-product">Add Product</button>
        <br>
        <br>
        <form id="product-form">
            <div id="product-container"></div>
            <div class="form-actions">
            
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
    <template id="product-template">
        <div class="product-block">
            <div class="form-grid">
                <div class="standard-fields">
                    <input placeholder="Name"  type="text" name="product_name[]">
                    <div class="inline-group">
                            <select name="product_type[]">
                                <option value="simple">Simple</option>
                                <option value="variable">Variable</option>
                                <option value="grouped">Grouped</option>
                                <option value="external">External/Affiliate</option>
                                <option value="subscription">Subscription</option>
                            </select>
                            <div class="external-url-wrapper" style="display:none;">
                        <label>External Product URL <input type="url" name="external_url[]"></label>
   
                    </div>
                    <div class="grouped-products-wrapper" style="display:none;">
                        
                        <select multiple name="grouped_children[]">
                            <!-- dynamically populated by JS -->
                        </select>
                 
                </div>
                        <input placeholder="Price"  type="number" name="price[]" step="0.01">
                        <input placeholder="Categories"  type="text" name="category[]">
                        <input placeholder="Tags"  type="text" name="tags[]">
                    </div>
                    <div class="inline-group">
                        <label><input type="checkbox" name="featured[]"> Feature</label>
                        <label><input type="checkbox" name="in_stock[]"> In Stock?</label>
                        <label><input type="checkbox" name="stock_managed[]"> Mng Stock</label>
                        <label><input type="checkbox" class="schedule-sale-checkbox"> Schedule Sale</label>
                        <input placeholder="# in stock"  type="number" name="stock_qty[]">
                        <div class="sale-fields" style="display:none;">
         <input placeholder="Sale Price"  type="number" name="sale_price[]" step="0.01" />
      <input type="date" name="sale_start[]" /> --
     <input type="date" name="sale_end[]" />
    </div>
                    </div>
                    <input type="button" class="upload_image_button button" value="Upload Image" />
                   <textarea placeholder="Short Description "  name="short_description[]"></textarea>
                     <textarea placeholder="Long Description"  name="long_description[]"></textarea>
                     <div class="attribute-container"></div>
<button type="button" class="add-attribute-btn">+ Add Product Attribute</button>
<div class="variable-info" style="display:none;">
                        <p style="color: #555; font-style: italic;">Quick Add Variations are coming soon. For now, manage variations in the regular WordPress product editor.</p>
                    </div>


        <div class="pro-fields">
                    <h3>Quick Add Pro</h3>
                    <label>Keyword <input type="text" disabled placeholder="Pro version only"></label>
                    <label>SEO Title <input type="text" disabled placeholder="Pro version only"></label>
                    <label>Meta Description <textarea disabled placeholder="Pro version only"></textarea></label>
                    <label>Social Media Title <input type="text" disabled placeholder="Pro version only"></label>
                    <label>Social Media Image <input type="file" disabled></label>
                    <label>Social Media Desc. <textarea disabled placeholder="Pro version only"></textarea></label>
                    <label>Schema <input type="text" disabled placeholder="Pro version only"></label>
                </div>
            </div>
        </div>
    </template>
    <?php
    wp_enqueue_media();
    wp_enqueue_script('ipf-script', plugin_dir_url(__FILE__) . 'script.js', ['jquery'], null, true);
    wp_localize_script('ipf-script', 'ipf_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ipf_nonce'),
        'grouped_products' => get_posts([
    'post_type' => 'product',
    'numberposts' => -1,
    'post_status' => 'publish',
    'meta_query' => [[
        'key' => '_product_type',
        'value' => 'simple'
    ]]
])
    ]);
    return ob_get_clean();
}

add_action('wp_ajax_ipf_save_product', 'ipf_save_product');
function ipf_save_product() {
    check_ajax_referer('ipf_nonce', 'nonce');

    $names = $_POST['product_name'] ?? [];

    if (!is_array($names)) {
        wp_send_json_error('Invalid submission');
    }

    $created = [];
    foreach ($names as $index => $name) {
        $sku = strtoupper(substr($name, 0, 2) . substr($name, -2));
        $id = null;
        for ($i = 1; $i <= 1000; $i++) {
            $candidate = str_pad(rand(1, 1000), 4, '0', STR_PAD_LEFT);
            if (!get_page_by_title($candidate, OBJECT, 'product')) {
                $id = $candidate;
                break;
            }
        }

        $post = [
            'post_title' => sanitize_text_field($name),
            'post_content' => sanitize_textarea_field($_POST['long_description'][$index]),
            'post_excerpt' => sanitize_text_field($_POST['short_description'][$index] ?? ''),

            'post_status' => 'publish',
            'post_type' => 'product',
        ];

        $product_id = wp_insert_post($post);
        if (!$product_id) continue;

        update_post_meta($product_id, '_price', wc_format_decimal($_POST['price'][$index]));
        update_post_meta($product_id, '_regular_price', wc_format_decimal($_POST['price'][$index]));
        update_post_meta($product_id, '_sku', $sku);
        update_post_meta($product_id, '_stock', intval($_POST['stock_qty'][$index] ?? 0));
        update_post_meta($product_id, '_manage_stock', !empty($_POST['stock_managed'][$index]) ? 'yes' : 'no');
        update_post_meta($product_id, '_featured', 'no');
        if (!empty($_POST['featured'][$index])) {
            update_post_meta($product_id, '_featured', 'yes');
            delete_post_meta($product_id, '_thumbnail_id'); // Clear any conflicts
            add_post_meta($product_id, '_visibility', 'visible');
        }
        
        update_post_meta($product_id, '_stock_status', !empty($_POST['in_stock'][$index]) ? 'instock' : 'outofstock');
        if (!empty($_POST['sale_price'][$index])) {
            update_post_meta($product_id, '_sale_price', wc_format_decimal($_POST['sale_price'][$index]));
        }
        if (!empty($_POST['sale_start'][$index])) {
            update_post_meta($product_id, '_sale_price_dates_from', strtotime($_POST['sale_start'][$index]));
        }
        if (!empty($_POST['sale_end'][$index])) {
            update_post_meta($product_id, '_sale_price_dates_to', strtotime($_POST['sale_end'][$index]));
        }

        // Handle attributes
        if (!empty($_POST['attribute_name'][$index])) {
            $attributes = [];
            foreach ($_POST['attribute_name'][$index] as $attr_index => $attr_name) {
                $attr_slug = wc_sanitize_taxonomy_name($attr_name);
                $values = array_map('trim', explode('|', $_POST['attribute_values'][$index][$attr_index]));

                $attributes[$attr_slug] = [
                    'name' => $attr_name,
                    'value' => implode('|', $values),
                    'is_visible' => 1,
                    'is_variation' => !empty($_POST['attribute_variation'][$index][$attr_index]) ? 1 : 0,
                    'is_taxonomy' => 0
                ];
            }
            update_post_meta($product_id, '_product_attributes', $attributes);
        }

        $type = sanitize_text_field($_POST['product_type'][$index]);
        wp_set_object_terms($product_id, $type, 'product_type', false);

        if ($type === 'external') {
            update_post_meta($product_id, '_product_url', esc_url_raw($_POST['external_url'][$index] ?? ''));
        }

        if ($type === 'grouped') {
            $grouped_ids = array_map('intval', $_POST['grouped_children'][$index] ?? []);
            update_post_meta($product_id, '_children', $grouped_ids);
        }

        if (!empty($_POST['category'][$index])) {
            $cats = array_map('trim', explode(',', $_POST['category'][$index]));
            $cat_ids = [];
            foreach ($cats as $cat_name) {
                $term = term_exists($cat_name, 'product_cat');
                if (!$term) {
                    $term = wp_insert_term($cat_name, 'product_cat');
                }
                if (!is_wp_error($term)) {
                    $cat_ids[] = intval($term['term_id']);
                }
            }
            if (!empty($cat_ids)) {
                wp_set_object_terms($product_id, $cat_ids, 'product_cat');
            }
        }
        
        if (!empty($_POST['tags'][$index])) {
            wp_set_post_terms($product_id, explode(',', sanitize_text_field($_POST['tags'][$index])), 'product_tag');
        }

        if (!empty($_POST['product_image'][$index])) {
            $image_url = esc_url_raw($_POST['product_image'][$index]);
            $attachment_id = attachment_url_to_postid($image_url);
            if ($attachment_id) {
                set_post_thumbnail($product_id, $attachment_id);
            }
        }
        

        $created[] = $product_id;
    }

    if (!empty($created)) {
        wp_send_json_success(['created' => $created]);
    } else {
        wp_send_json_error('No products created');
    }
}
