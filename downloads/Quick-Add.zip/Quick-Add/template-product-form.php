<style>
  .product-block {
    display: inline-block;
    vertical-align: top;
    width: 30%;
    margin: 1%;
    padding: 20px;
    background-color: #f9f9f9;
    border: 1px solid #ddd;
    border-radius: 6px;
    box-sizing: border-box
  }

  .product-block label {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
    gap: 10px
  }

  .product-block label select,
  .product-block label textarea {
    flex: 1 1 auto;
    max-width: 60%
  }

  .product-block input[type="checkbox"] {
    margin-left: auto
  }

  .product-block .download-file-block label,
  .product-block .sale-fields label,
  .product-block .external-url-wrapper label {
    flex-direction: column;
    align-items: flex-start
  }

  .download-file-block,
  .sale-fields,
  .external-url-wrapper,
  .download-fields,
  .shipping-fields {
    margin-left: 10px
  }

  @media screen and (max-width: 768px) {
    .product-block {
      width: 100%;
      margin-bottom: 20px;
    }
  }
</style>
<div class="product-block">
  <h2>New Product</h2><label>Product Name <input type="text" name="product_name[]"></label><label>Product Type <select
      name="product_type[]">
      <option value="simple">Simple</option>
      <option value="variable">Variable</option>
      <option value="grouped">Grouped</option>
      <option value="external">External/Affiliate</option>
    </select></label><label>SKU <input type="text" name="sku[]"></label><label>GTIN/UPC/EAN/ISBN <input type="text"
      name="gtin[]"></label><label>Product Image <button
      class="upload_image_button button">Upload</button></label><label>Regular Price <input type="text"
      name="regular_price[]"></label><label>Sale Price <input type="text" name="sale_price[]"></label><label><input
      type="checkbox" class="schedule-sale-checkbox">Schedule Sale</label>
  <div class="sale-fields" style="display:none"><label>Sale Start Date <input type="date"
        name="sale_start[]"></label><label>Sale End Date <input type="date" name="sale_end[]"></label></div>
  <label>Product Description <textarea name="product_description[]"></textarea></label><label>Short Description
    <textarea name="short_description[]"></textarea></label><label>Categories <input type="text" name="categories[]"
      placeholder="Comma-separated"></label><label>Tags <input type="text" name="tags[]"
      placeholder="Comma-separated"></label><label>Tax Status <select name="tax_status[]">
      <option value="taxable">Taxable</option>
      <option value="shipping">Shipping only</option>
      <option value="none">None</option>
    </select></label><label>Tax Class <input type="text" name="tax_class[]"></label><label>Weight <input type="text"
      name="weight[]"></label><label>Length <input type="text" name="length[]"></label><label>Width <input type="text"
      name="width[]"></label><label>Height <input type="text" name="height[]"></label><label>Shipping Class <input
      type="text" name="shipping_class[]"></label><label><input type="checkbox" name="manage_stock[]">Manage
    Stock</label><label>Stock Quantity <input type="number" name="stock_quantity[]"></label><label>Allow Backorders
    <select name="backorders[]">
      <option value="no">Do not allow</option>
      <option value="notify">Allow, but notify</option>
      <option value="yes">Allow</option>
    </select></label><label>Stock Status <select name="stock_status[]">
      <option value="instock">In stock</option>
      <option value="outofstock">Out of stock</option>
      <option value="onbackorder">On backorder</option>
    </select></label><label><input type="checkbox" name="sold_individually[]">Sold Individually</label>
  <div class="external-url-wrapper" style="display:none"><label>External URL <input type="url"
        name="external_url[]"></label><label>Button Text <input type="text" name="button_text[]"></label></div>
  <label><input type="checkbox" name="virtual[]">Virtual</label><label><input type="checkbox"
      class="downloadable-toggle">Downloadable</label>
  <div class="download-fields" style="display:none">
    <div class="download-file-block"><label>Download URL <input type="url"
          name="download_url[0][]"></label><label>Download Name <input type="text" name="download_name[0][]"></label>
    </div><button class="add-download-file button">+ Add Download</button>
  </div><label>Purchase Note <textarea name="purchase_note[]"></textarea></label><label><input type="checkbox"
      name="reviews_allowed[]" checked>Enable Reviews</label><label>Slug <input type="text"
      name="slug[]"></label><label>Menu Order <input type="number" name="menu_order[]" value="0"></label><label>Catalog
    Visibility <select name="catalog_visibility[]">
      <option value="visible">Shop and search</option>
      <option value="catalog">Shop only</option>
      <option value="search">Search only</option>
      <option value="hidden">Hidden</option>
    </select></label><label><input type="checkbox" name="featured[]">Featured</label><label>Status <select
      name="status[]">
      <option value="publish">Publish</option>
      <option value="draft">Draft</option>
      <option value="pending">Pending</option>
    </select></label>
</div>